# 💎 TikTok Vision 26 · iOS 26 Liquid Frosted Glass Edition

> Ứng dụng trải nghiệm TikTok tương lai với phong cách thiết kế **iOS 26 Liquid Frosted Glass (Thủy tinh đục mờ OLED)**, hệ thống **Emoji pha lê 3D tự chế 100%**, nhắn tin Direct Chat thời gian thực, Creator Studio đăng tải video/ảnh ghép nhạc, và khiên bảo mật **Anti-Crack Secure Enclave Armor**.

---

## ✨ Tính Năng Nổi Bật

### 1. 🪟 Giao Diện Kính Đục Mờ Siêu Thực (iOS 26 Liquid Glass)
- Hiệu ứng đa tầng `backdrop-filter: blur(28px) saturate(210%) brightness(1.12)` cùng viền khúc xạ ánh sáng (chromatic aberration specular glow).
- Khung máy **iPhone 26 Pro Titanium viền mỏng vô cực** có thể chuyển đổi giữa chế độ điện thoại và **Toàn màn hình (Fullscreen)**.
- **Dynamic Island 2.0 (Holo Capsule)**: Tương tác chạm mở rộng, hiển thị sóng nhạc equalizer, thông báo tin nhắn và tiến trình upload video thời gian thực.
- Thanh Dock kính nổi (Liquid Frosted Glass Dock) mượt mà 120Hz.

### 2. 💖 100% Emoji Pha Lê 3D Tự Thiết Kế (Zero Font / Icon Dependencies)
Không sử dụng bất kỳ font icon hay emoji mặc định nào. Toàn bộ được tạo thủ công bằng SVG vector 3D đa tầng:
- **3D Crystal Heart**: Trái tim pha lê khúc xạ ánh sáng ruby, phát nổ hạt ánh sáng khi bấm đúp vào màn hình.
- **Liquid Prismatic Flame**: Lửa thủy tinh 3 tầng ánh vàng cam tím.
- **Crystal Cry-Joy Face**: Cầu kính 3D với 2 giọt nước mắt pha lê xanh ngọc phản chiếu ánh sáng.
- **Diamond Star-Struck Face**: Đôi mắt ngôi sao kim cương 8 cánh xoay phát quang.
- **Cosmic Mindblown Face**: Đầu kính mở bung cực quang Aurora neon.
- **Sapphire Thumbs-Up**: Bàn tay thủy tinh lam ngọc viền ánh kim.
- **Holographic Vinyl Disc**: Đĩa than kính đổi màu theo góc nhìn với nốt nhạc bay lơ lửng.

### 3. 💬 Nhắn Tin & Chat Trực Tiếp (Direct Messaging DM)
- Khung chứa tin nhắn bo góc kính đục mờ OLED chuẩn iOS 26.
- Đầy đủ Avatar, Tên hiển thị, `@username` người nhận, trạng thái online xanh ngọc.
- Hỗ trợ gửi tin nhắn văn bản, đính kèm ảnh, tin nhắn thoại (Voice note với sóng âm tương tác).
- Khay phản ứng emoji kính 3D siêu nhạy.
- Mô phỏng người nhận trả lời tự động với thông báo pop-up trên Dynamic Island.

### 4. 🎬 Studio Đăng Ảnh / Video & Ghép Nhạc
- Nút Tạo (+) mở ngay **Creator Studio**.
- Cho phép chọn tệp thật từ thiết bị của bạn (hỗ trợ JPG, PNG, MP4, WebM).
- **Kho nhạc ghép video**: Lựa chọn các bài nhạc Spatial Audio 2026 với nút nghe thử.
- Chọn bộ lọc kính (Cyberpunk, Holographic Glass, Midnight Glitch).
- Đăng tải tức thì: Chèn video mới lên vị trí đầu tiên của bảng tin TikTok để trải nghiệm ngay.

### 5. 🛡️ Khiên Bảo Mật Anti-Crack (Secure Enclave Armor v26.4)
- **Tự động phòng thủ Closure Engine**: Kiểm tra tính toàn vẹn runtime hash.
- **Chống Debugger & Console Hijacking**: Bẫy timing probe ngăn chặn can thiệp qua DevTools.
- **DOM Mutation Guard**: Ngăn chặn các script lạ hoặc iframe injection can thiệp giao diện.
- Con dấu bản quyền cryptotoken trên từng phiên chạy.

---

## 📲 Hướng Dẫn Cài Lên iPhone Trực Tiếp (10 Giây - Khuyên Dùng)

Bạn không cần máy tính hay tài khoản Apple Developer để trải nghiệm như một App Native:

1. Chạy server trên máy tính:
   ```bash
   python -m http.server 8089
   ```
2. Trên iPhone (cùng mạng Wi-Fi), mở trình duyệt **Safari** và truy cập:
   `http://<IP-Máy-Tính>:8089/`
3. Nhấn vào biểu tượng **Chia sẻ (Share)** ở thanh dưới cùng của Safari.
4. Chọn **"Thêm vào Màn hình chính" (Add to Home Screen)**.
5. Biểu tượng **TikTok 26** sẽ xuất hiện trên màn hình chính iPhone. Khi mở ra, ứng dụng sẽ chạy **toàn màn hình 100% không còn thanh URL duyệt web**, hỗ trợ đầy đủ cử chỉ vuốt, âm thanh xúc giác và hiệu ứng kính đục!

---

## 📦 Hướng Dẫn Đóng Gói File `.ipa` (Cho Sideloadly / TrollStore / AltStore)

Project đã được cài đặt sẵn cấu hình **Capacitor iOS**:

1. Cài đặt các dependencies:
   ```bash
   npm install
   ```
2. Thêm nền tảng iOS:
   ```bash
   npx cap add ios
   ```
3. Đồng bộ code:
   ```bash
   npx cap sync
   ```
4. Mở trong Xcode (trên macOS):
   ```bash
   npx cap open ios
   ```
5. Trong Xcode: Chọn **Product > Archive**, sau đó xuất file `TikTokVision26.ipa` để ký và cài qua TrollStore, AltStore, hoặc Sideloadly.
