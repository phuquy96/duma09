/**
 * TikTok Vision 26 - iOS 26 Frosted Glass Engine
 * Pure Vanilla JS, Web Audio API, Hand-crafted Glass Emojis
 */

class TikTokVision26 {
  constructor() {
    this.videos = [
      {
        id: 1,
        author: 'elysia.2026',
        name: 'Elysia Vũ ✦',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        bg: 'assets/tiktok_video_cyber_tokyo_1790520635648.jpg',
        caption: 'Trải nghiệm một buổi tối mưa tại Neo Tokyo 2026. Mọi bảng hiệu quảng cáo đều là holographic spatial glass tuyệt đẹp! 🌧️✨',
        tags: ['#NeoTokyo', '#iOS26', '#VisionOS', '#Cyberpunk', '#SpatialGlass'],
        music: '♫ Cyber Tokyo Rain Vibes - Synthwave 2026 (Spatial Lossless)',
        likes: 1845200,
        comments: 24510,
        bookmarks: 89200,
        shares: 41600,
        liked: false,
        bookmarked: false,
        followed: false,
        hasCanvasFX: 'rain'
      },
      {
        id: 2,
        author: 'tech_future.vn',
        name: 'Vinh Xô Spatial',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        bg: 'assets/tiktok_video_spatial_gadget_1790520651574.jpg',
        caption: 'Đập hộp siêu phẩm iPhone 26 Pro Holographic Glass đầu tiên tại Việt Nam! Khung titanium viền ánh kính siêu thực 📱💎',
        tags: ['#iPhone26', '#Unboxing', '#AppleVision', '#LiquidGlass', '#Review'],
        music: '♫ iOS 26 Soundscape - Liquid Crystal Audio',
        likes: 2410800,
        comments: 56120,
        bookmarks: 142000,
        shares: 98400,
        liked: true,
        bookmarked: false,
        followed: true,
        hasCanvasFX: 'particles'
      },
      {
        id: 3,
        author: 'mai_dancer26',
        name: 'Mai Dancer',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        bg: 'assets/tiktok_video_cyber_tokyo_1790520635648.jpg',
        caption: 'Bắt trend điệu nhảy Neon Cyberpunk cùng nhóm bạn dưới ánh đèn phố ảo diệu 💃⚡ Mọi người chấm mấy điểm?',
        tags: ['#DanceTrend', '#TikTokDance', '#CyberVibe', '#VietNam'],
        music: '♫ Neon Beat Bass Drop - DJ Spatial Tokyo',
        likes: 940500,
        comments: 12840,
        bookmarks: 45100,
        shares: 19300,
        liked: false,
        bookmarked: false,
        followed: false,
        hasCanvasFX: 'aurora'
      }
    ];

    this.commentsData = [
      {
        id: 101,
        author: 'quang_anh_99',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        text: 'Nút kính bấm đục đục đỉnh chóp thật sự! Giao diện iOS 26 mượt gấp đôi TikTok hiện tại luôn 🔥',
        time: '2 phút trước',
        likes: 1420,
        liked: false
      },
      {
        id: 102,
        author: 'linh_aesthetic',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        text: 'Mấy cái emoji pha lê 3D tự làm nhìn xịn quá, không bị đụng hàng icon bình thường tí nào 😍✨',
        time: '15 phút trước',
        likes: 852,
        liked: true
      },
      {
        id: 103,
        author: 'hoang_apple',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        text: 'Nhìn hiệu ứng Dynamic Island với vinyl xoay nổi nốt nhạc phê dã man anh em ơi! 👏💎',
        time: '1 giờ trước',
        likes: 419,
        liked: false
      }
    ];

    this.currentIndex = 0;
    this.isPlaying = true;
    this.isMuted = false;
    this.audioCtx = null;
    this.synthInterval = null;
    this.lastTapTime = 0;

    this.init();
  }

  init() {
    // Inject global SVG definitions
    const defsContainer = document.createElement('div');
    defsContainer.innerHTML = GlassAssets.getSvgDefs();
    document.body.prepend(defsContainer);

    this.renderFeed();
    this.setupEventListeners();
    this.setupCanvasVisualizers();
    this.setupDynamicIsland();
    this.setupAudioSynthesizer();
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);
  }

  // Format big numbers like TikTok (1.4M, 24.5K)
  formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  // Render TikTok Video Feed
  renderFeed() {
    const feedContainer = document.getElementById('tiktokFeed');
    if (!feedContainer) return;
    feedContainer.innerHTML = '';

    this.videos.forEach((video, index) => {
      const card = document.createElement('div');
      card.className = 'video-card';
      card.dataset.index = index;

      card.innerHTML = `
        <!-- Background Media -->
        <img class="video-bg" src="${video.bg}" alt="${video.caption}">
        <canvas class="video-canvas-effect" id="canvas-fx-${video.id}"></canvas>
        <div class="video-vignette"></div>

        <!-- Video Tap Area (Play/Pause & Double-Tap Heart) -->
        <div class="video-tap-area" data-index="${index}">
          <div class="play-pause-indicator" id="playIndicator-${index}">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="#ffffff">
              <polygon points="6,4 20,12 6,20" />
            </svg>
          </div>
        </div>

        <!-- Right-side Action Stack (iOS 26 Frosted Glass) -->
        <div class="right-action-stack">
          <!-- Avatar + Follow Badge -->
          <div class="avatar-glass-wrap" data-action="profile" data-index="${index}">
            <img class="avatar-glass-img" src="${video.avatar}" alt="${video.name}">
            <div class="avatar-follow-badge ${video.followed ? 'followed' : ''}" data-action="follow" data-index="${index}">
              ${video.followed ? 
                `<svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M5 13L9 17L19 7" stroke="#000000" stroke-width="3" stroke-linecap="round"/></svg>` : 
                `<svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 5V19M5 12H19" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/></svg>`
              }
            </div>
          </div>

          <!-- Glass Like Button -->
          <div class="glass-action-item" data-action="like" data-index="${index}">
            <div class="glass-action-circle" id="likeBtn-${index}">
              ${GlassAssets.getGlassHeart(video.liked, 34)}
            </div>
            <span class="glass-action-count" id="likeCount-${index}">${this.formatNumber(video.likes)}</span>
          </div>

          <!-- Glass Comment Button -->
          <div class="glass-action-item" data-action="comment" data-index="${index}">
            <div class="glass-action-circle">
              ${GlassAssets.getGlassComment(32)}
            </div>
            <span class="glass-action-count">${this.formatNumber(video.comments)}</span>
          </div>

          <!-- Glass Bookmark Button -->
          <div class="glass-action-item" data-action="bookmark" data-index="${index}">
            <div class="glass-action-circle" id="bookmarkBtn-${index}">
              ${GlassAssets.getGlassBookmark(video.bookmarked, 32)}
            </div>
            <span class="glass-action-count" id="bookmarkCount-${index}">${this.formatNumber(video.bookmarks)}</span>
          </div>

          <!-- Glass Share Button -->
          <div class="glass-action-item" data-action="share" data-index="${index}">
            <div class="glass-action-circle">
              ${GlassAssets.getGlassShare(30)}
            </div>
            <span class="glass-action-count">${this.formatNumber(video.shares)}</span>
          </div>

          <!-- Rotating Vinyl Disc -->
          <div class="glass-action-item" data-action="music" data-index="${index}">
            ${GlassAssets.getGlassDisc(video.avatar, 44)}
          </div>
        </div>

        <!-- Video Bottom Info Overlay -->
        <div class="video-info-overlay">
          <div class="author-line">
            <span class="author-username" data-action="profile">
              @${video.author}
              <span class="verified-glass-badge">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13L9 17L19 7" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
                </svg>
              </span>
            </span>
            <button class="follow-text-btn ${video.followed ? 'followed' : ''}" data-action="follow" data-index="${index}">
              ${video.followed ? 'Đang follow' : 'Follow'}
            </button>
          </div>

          <div class="video-caption">
            ${video.caption}
            <div style="margin-top: 4px;">
              ${video.tags.map(t => `<span class="caption-hashtag">${t}</span>`).join(' ')}
            </div>
          </div>

          <div class="music-glass-pill" data-action="music">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M9 18V5L21 3V16" stroke="var(--neon-cyan)" stroke-width="2"/>
              <circle cx="6" cy="18" r="3" fill="var(--neon-cyan)"/>
              <circle cx="18" cy="16" r="3" fill="var(--neon-cyan)"/>
            </svg>
            <span class="music-marquee">${video.music} &nbsp;&nbsp;&nbsp;&nbsp; ${video.music}</span>
          </div>
        </div>

        <!-- Scrub Progress Bar -->
        <div class="video-progress-container" id="progressBar-${index}">
          <div class="video-progress-fill" id="progressFill-${index}"></div>
        </div>
      `;

      feedContainer.appendChild(card);
    });

    this.startProgressAnimation();
  }

  // Smooth fake progress bar for video feel
  startProgressAnimation() {
    let progress = 0;
    clearInterval(this.progressTimer);
    this.progressTimer = setInterval(() => {
      if (!this.isPlaying) return;
      progress = (progress + 0.5) % 100;
      const fill = document.getElementById(`progressFill-${this.currentIndex}`);
      if (fill) fill.style.width = `${progress}%`;
    }, 100);
  }

  // Setup Web Audio API Synthesizer (iOS 26 glass clicks, hearts, spatial chords)
  setupAudioSynthesizer() {
    const initAudio = () => {
      if (!this.audioCtx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.audioCtx = new AudioContext();
        this.playSpatialAmbientTrack();
      }
      document.removeEventListener('click', initAudio);
      document.removeEventListener('touchstart', initAudio);
    };
    document.addEventListener('click', initAudio, { once: true });
    document.addEventListener('touchstart', initAudio, { once: true });
  }

  // iOS 26 Glass Pop Sound FX
  playGlassSound(type = 'click') {
    if (this.isMuted || !this.audioCtx) return;
    try {
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      if (type === 'heart') {
        // Double pulse warm resonant heart sound
        osc.type = 'sine';
        osc.frequency.setValueAtTime(160, now);
        osc.frequency.exponentialRampToValueAtTime(70, now + 0.18);
        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'glass') {
        // High crystalline refraction pop
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1400, now);
        osc.frequency.exponentialRampToValueAtTime(450, now + 0.08);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.09);
      } else {
        // Subtle haptic tick
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.05);
      }
    } catch (e) {
      // Audio fallback silent
    }
  }

  // Ambient Generative Lo-Fi Synth Track (Continuous Chill Spatial Music)
  playSpatialAmbientTrack() {
    if (!this.audioCtx) return;
    const chords = [
      [261.63, 329.63, 392.00, 493.88], // Cmaj7
      [220.00, 261.63, 329.63, 392.00], // Am7
      [174.61, 220.00, 261.63, 329.63], // Fmaj7
      [196.00, 246.94, 293.66, 349.23]  // G7
    ];
    let chordIdx = 0;

    const playChord = () => {
      if (this.isMuted || !this.isPlaying || !this.audioCtx) return;
      const now = this.audioCtx.currentTime;
      const currentChord = chords[chordIdx % chords.length];
      chordIdx++;

      currentChord.forEach((freq, i) => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        const filter = this.audioCtx.createBiquadFilter();

        osc.type = i % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(650, now);
        filter.frequency.exponentialRampToValueAtTime(350, now + 2.4);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.05 / (i + 1), now + 0.4);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.5);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.audioCtx.destination);

        osc.start(now);
        osc.stop(now + 2.6);
      });
    };

    setInterval(playChord, 2600);
  }

  // Setup Dynamic Visualizer Canvases (Rain mist, cyber particles, aurora)
  setupCanvasVisualizers() {
    this.videos.forEach(video => {
      const canvas = document.getElementById(`canvas-fx-${video.id}`);
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let w = (canvas.width = canvas.offsetWidth || 380);
      let h = (canvas.height = canvas.offsetHeight || 750);

      window.addEventListener('resize', () => {
        w = canvas.width = canvas.offsetWidth || 380;
        h = canvas.height = canvas.offsetHeight || 750;
      });

      const particles = [];
      for (let i = 0; i < 40; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          speedY: Math.random() * 2 + 1,
          speedX: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 2 + 1,
          color: Math.random() > 0.5 ? 'rgba(0, 242, 254, 0.6)' : 'rgba(255, 45, 110, 0.5)',
          opacity: Math.random() * 0.7 + 0.3
        });
      }

      const animate = () => {
        ctx.clearRect(0, 0, w, h);
        particles.forEach(p => {
          p.y += p.speedY;
          p.x += p.speedX;
          if (p.y > h) p.y = 0;
          if (p.x > w) p.x = 0;
          if (p.x < 0) p.x = w;

          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        });
        requestAnimationFrame(animate);
      };
      animate();
    });
  }

  // Double-tap to spawn bursting 3D Glass Heart at exact coordinates
  triggerDoubleTapHeart(x, y, cardIndex) {
    const feed = document.getElementById('tiktokFeed');
    const heart = document.createElement('div');
    heart.className = 'burst-heart';
    heart.style.left = `${x}px`;
    heart.style.top = `${y}px`;
    heart.innerHTML = GlassAssets.getGlassHeart(true, 72);

    feed.appendChild(heart);
    setTimeout(() => heart.remove(), 900);

    // Toggle liked if not already liked
    const video = this.videos[cardIndex];
    if (!video.liked) {
      this.toggleLike(cardIndex);
    } else {
      this.playGlassSound('heart');
    }
  }

  toggleLike(index) {
    const video = this.videos[index];
    video.liked = !video.liked;
    video.likes += video.liked ? 1 : -1;

    const likeBtn = document.getElementById(`likeBtn-${index}`);
    const likeCount = document.getElementById(`likeCount-${index}`);
    if (likeBtn) likeBtn.innerHTML = GlassAssets.getGlassHeart(video.liked, 34);
    if (likeCount) likeCount.textContent = this.formatNumber(video.likes);

    this.playGlassSound('heart');
  }

  toggleBookmark(index) {
    const video = this.videos[index];
    video.bookmarked = !video.bookmarked;
    video.bookmarks += video.bookmarked ? 1 : -1;

    const btn = document.getElementById(`bookmarkBtn-${index}`);
    const count = document.getElementById(`bookmarkCount-${index}`);
    if (btn) btn.innerHTML = GlassAssets.getGlassBookmark(video.bookmarked, 32);
    if (count) count.textContent = this.formatNumber(video.bookmarks);

    this.playGlassSound('glass');
  }

  toggleFollow(index) {
    const video = this.videos[index];
    video.followed = !video.followed;
    this.renderFeed();
    this.playGlassSound('glass');
  }

  // Setup Event Listeners
  setupEventListeners() {
    const feed = document.getElementById('tiktokFeed');

    // Feed Scroll Detection for active card
    feed.addEventListener('scroll', () => {
      const scrollPos = feed.scrollTop;
      const height = feed.clientHeight;
      const newIdx = Math.round(scrollPos / height);
      if (newIdx !== this.currentIndex && newIdx >= 0 && newIdx < this.videos.length) {
        this.currentIndex = newIdx;
        this.updateDynamicIslandForCurrentVideo();
      }
    });

    // Delegated click handling
    feed.addEventListener('click', (e) => {
      const tapArea = e.target.closest('.video-tap-area');
      const actionItem = e.target.closest('[data-action]');

      if (actionItem) {
        const action = actionItem.dataset.action;
        const index = parseInt(actionItem.dataset.index || this.currentIndex);
        this.handleAction(action, index);
        return;
      }

      if (tapArea) {
        const index = parseInt(tapArea.dataset.index);
        const now = Date.now();
        const rect = feed.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        if (now - this.lastTapTime < 320) {
          // Double tap detected!
          this.triggerDoubleTapHeart(x, y, index);
          this.lastTapTime = 0;
        } else {
          // Single tap - toggle Play / Pause
          this.lastTapTime = now;
          setTimeout(() => {
            if (this.lastTapTime === now) {
              this.togglePlayPause(index);
            }
          }, 320);
        }
      }
    });

    // Comments Sheet setup
    this.setupCommentsSheet();

    // Share Sheet setup
    this.setupShareSheet();

    // Bottom Navigation Bar tabs
    this.setupDockNavigation();

    // External Controls (Frame toggle, sound, IPA guide)
    this.setupExternalControls();

    // Camera Studio Controls
    this.setupCameraStudio();
  }

  togglePlayPause(index) {
    this.isPlaying = !this.isPlaying;
    const indicator = document.getElementById(`playIndicator-${index}`);
    if (indicator) {
      indicator.classList.add('show');
      setTimeout(() => indicator.classList.remove('show'), 600);
    }
    this.playGlassSound('click');
  }

  handleAction(action, index) {
    switch(action) {
      case 'like':
        this.toggleLike(index);
        break;
      case 'bookmark':
        this.toggleBookmark(index);
        break;
      case 'follow':
        this.toggleFollow(index);
        break;
      case 'comment':
        this.openCommentsSheet(index);
        break;
      case 'share':
        this.openShareSheet(index);
        break;
      case 'profile':
        this.openProfileTab();
        break;
      case 'music':
        this.expandDynamicIsland();
        break;
    }
  }

  // Dynamic Island
  setupDynamicIsland() {
    const island = document.getElementById('dynamicIsland');
    if (!island) return;

    island.addEventListener('click', () => {
      this.playGlassSound('glass');
      island.classList.toggle('expanded');
    });

    this.updateDynamicIslandForCurrentVideo();
  }

  expandDynamicIsland() {
    const island = document.getElementById('dynamicIsland');
    if (island) {
      island.classList.add('expanded');
      this.playGlassSound('glass');
    }
  }

  updateDynamicIslandForCurrentVideo() {
    const video = this.videos[this.currentIndex];
    const islandLabel = document.getElementById('islandLabel');
    if (islandLabel && video) {
      islandLabel.textContent = video.author;
    }
  }

  // Setup Comments Sheet with Custom Glass Emojis
  setupCommentsSheet() {
    const sheet = document.getElementById('commentsSheet');
    const backdrop = document.getElementById('sheetBackdrop');
    const closeBtn = document.getElementById('closeCommentsBtn');
    const emojiBar = document.getElementById('commentsEmojiBar');
    const sendBtn = document.getElementById('sendCommentBtn');
    const input = document.getElementById('commentInputField');

    // Populate custom handcrafted glass emoji quick bar
    if (emojiBar) {
      emojiBar.innerHTML = `
        <div class="quick-emoji-item" data-emoji="heart">${GlassAssets.getGlassHeart(true, 28)}</div>
        <div class="quick-emoji-item" data-emoji="fire">${GlassAssets.getGlassFlame(28)}</div>
        <div class="quick-emoji-item" data-emoji="laugh">${GlassAssets.getGlassLaughTears(28)}</div>
        <div class="quick-emoji-item" data-emoji="star">${GlassAssets.getGlassStarStruck(28)}</div>
        <div class="quick-emoji-item" data-emoji="mindblown">${GlassAssets.getGlassMindBlown(28)}</div>
        <div class="quick-emoji-item" data-emoji="thumbsup">${GlassAssets.getGlassThumbsUp(28)}</div>
      `;

      emojiBar.addEventListener('click', (e) => {
        const item = e.target.closest('.quick-emoji-item');
        if (!item) return;
        const emojiType = item.dataset.emoji;
        const emojiLabels = {
          heart: '❤️💎',
          fire: '🔥⚡',
          laugh: '😂✨',
          star: '🤩🌟',
          mindblown: '🤯🌌',
          thumbsup: '👍💎'
        };
        input.value += ' ' + (emojiLabels[emojiType] || '✨');
        input.focus();
        this.playGlassSound('glass');
      });
    }

    const closeSheet = () => {
      sheet.classList.remove('open');
      backdrop.classList.remove('open');
      this.playGlassSound('click');
    };

    if (closeBtn) closeBtn.addEventListener('click', closeSheet);
    if (backdrop) backdrop.addEventListener('click', closeSheet);

    const submitComment = () => {
      const val = input.value.trim();
      if (!val) return;
      this.commentsData.unshift({
        id: Date.now(),
        author: 'ban_la_nhat_2026',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        text: val,
        time: 'Vừa xong',
        likes: 1,
        liked: true
      });
      input.value = '';
      this.renderCommentsList();
      this.playGlassSound('heart');
    };

    if (sendBtn) sendBtn.addEventListener('click', submitComment);
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') submitComment();
      });
    }
  }

  openCommentsSheet(index) {
    const sheet = document.getElementById('commentsSheet');
    const backdrop = document.getElementById('sheetBackdrop');
    this.renderCommentsList();
    sheet.classList.add('open');
    backdrop.classList.add('open');
    this.playGlassSound('glass');
  }

  renderCommentsList() {
    const list = document.getElementById('commentsList');
    if (!list) return;
    list.innerHTML = this.commentsData.map(c => `
      <div class="comment-item">
        <img class="comment-avatar" src="${c.avatar}" alt="${c.author}">
        <div class="comment-content">
          <div class="comment-author-name">@${c.author} · ${c.time}</div>
          <div class="comment-text">${c.text}</div>
          <div class="comment-actions">
            <span>Trả lời</span>
            <span>Dịch</span>
          </div>
        </div>
        <div class="comment-like-col" onclick="window.tikTokApp.toggleCommentLike(${c.id})">
          ${GlassAssets.getGlassHeart(c.liked, 20)}
          <span style="font-size:10px; color:rgba(255,255,255,0.7);">${c.likes}</span>
        </div>
      </div>
    `).join('');
  }

  toggleCommentLike(commentId) {
    const c = this.commentsData.find(item => item.id === commentId);
    if (!c) return;
    c.liked = !c.liked;
    c.likes += c.liked ? 1 : -1;
    this.renderCommentsList();
    this.playGlassSound('heart');
  }

  // Setup Share Sheet (iOS 26 AirDrop & Action Grid)
  setupShareSheet() {
    const sheet = document.getElementById('shareSheet');
    const backdrop = document.getElementById('sheetBackdrop');
    const closeBtn = document.getElementById('closeShareBtn');

    const closeShare = () => {
      sheet.classList.remove('open');
      backdrop.classList.remove('open');
      this.playGlassSound('click');
    };

    if (closeBtn) closeBtn.addEventListener('click', closeShare);

    const shareGrid = document.getElementById('shareGrid');
    if (shareGrid) {
      shareGrid.addEventListener('click', (e) => {
        const btn = e.target.closest('.share-grid-btn');
        if (!btn) return;
        const action = btn.dataset.share;
        this.playGlassSound('glass');
        alert(`iOS 26 Spatial: Đã kích hoạt [${action.toUpperCase()}] thành công!`);
        closeShare();
      });
    }
  }

  openShareSheet(index) {
    const sheet = document.getElementById('shareSheet');
    const backdrop = document.getElementById('sheetBackdrop');
    sheet.classList.add('open');
    backdrop.classList.add('open');
    this.playGlassSound('glass');
  }

  // Setup Bottom Dock Navigation
  setupDockNavigation() {
    const dock = document.getElementById('bottomDock');
    if (!dock) return;

    dock.addEventListener('click', (e) => {
      const item = e.target.closest('.dock-item');
      if (!item) return;

      const tab = item.dataset.tab;
      document.querySelectorAll('.dock-item').forEach(d => d.classList.remove('active'));
      item.classList.add('active');

      this.playGlassSound('glass');

      if (tab === 'home') {
        this.hideAllTabViews();
      } else if (tab === 'discover') {
        this.openDiscoverTab();
      } else if (tab === 'create') {
        if (window.postStudio) {
          window.postStudio.openStudio();
        } else {
          this.openCameraStudio();
        }
      } else if (tab === 'inbox') {
        this.openInboxTab();
      } else if (tab === 'profile') {
        this.openProfileTab();
      }
    });
  }

  hideAllTabViews() {
    document.querySelectorAll('.full-screen-tab-view').forEach(v => v.classList.remove('active'));
  }

  openDiscoverTab() {
    this.hideAllTabViews();
    const tab = document.getElementById('discoverTabView');
    if (tab) tab.classList.add('active');
  }

  openInboxTab() {
    this.hideAllTabViews();
    const tab = document.getElementById('inboxTabView');
    if (tab) tab.classList.add('active');
  }

  openProfileTab() {
    this.hideAllTabViews();
    const tab = document.getElementById('profileTabView');
    if (tab) tab.classList.add('active');
  }

  // Setup Camera Studio Modal
  setupCameraStudio() {
    const modal = document.getElementById('cameraStudioModal');
    const closeBtn = document.getElementById('closeCameraBtn');
    const shutter = document.getElementById('cameraShutter');
    const filters = document.querySelectorAll('.filter-chip');
    const filterOverlay = document.getElementById('cameraFilterOverlay');

    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('open');
        this.playGlassSound('click');
      });
    }

    filters.forEach(chip => {
      chip.addEventListener('click', () => {
        filters.forEach(f => f.classList.remove('active'));
        chip.classList.add('active');
        const filterName = chip.dataset.filter;
        filterOverlay.className = `camera-filter-overlay ${filterName}`;
        this.playGlassSound('glass');
      });
    });

    if (shutter) {
      shutter.addEventListener('click', () => {
        this.playGlassSound('heart');
        shutter.style.transform = 'scale(0.85)';
        setTimeout(() => {
          shutter.style.transform = '';
          alert('Đã quay video clip với bộ lọc Spatial Glass 2026 thành công!');
          modal.classList.remove('open');
        }, 400);
      });
    }
  }

  openCameraStudio() {
    const modal = document.getElementById('cameraStudioModal');
    if (modal) {
      modal.classList.add('open');
      this.playGlassSound('glass');
    }
  }

  // External Controls: Device frame toggle, sound, IPA guide modal
  setupExternalControls() {
    const frameBtn = document.getElementById('btnToggleFrame');
    const soundBtn = document.getElementById('btnToggleSound');
    const ipaBtn = document.getElementById('btnIpaGuide');
    const device = document.getElementById('deviceWrapper');

    if (frameBtn && device) {
      frameBtn.addEventListener('click', () => {
        device.classList.toggle('fullscreen-mode');
        const isFull = device.classList.contains('fullscreen-mode');
        frameBtn.textContent = isFull ? '📱 Khung iPhone 26' : '🖥️ Toàn màn hình';
        this.playGlassSound('glass');
      });
    }

    if (soundBtn) {
      soundBtn.addEventListener('click', () => {
        this.isMuted = !this.isMuted;
        soundBtn.textContent = this.isMuted ? '🔇 Âm thanh: Tắt' : '🔊 Âm thanh: Bật';
        this.playGlassSound('glass');
      });
    }

    if (ipaBtn) {
      ipaBtn.addEventListener('click', () => {
        const ipaModal = document.getElementById('ipaGuideModal');
        if (ipaModal) {
          ipaModal.classList.add('open');
          document.getElementById('sheetBackdrop').classList.add('open');
        }
        this.playGlassSound('glass');
      });
    }

    const closeIpaBtn = document.getElementById('closeIpaGuideBtn');
    if (closeIpaBtn) {
      closeIpaBtn.addEventListener('click', () => {
        document.getElementById('ipaGuideModal').classList.remove('open');
        document.getElementById('sheetBackdrop').classList.remove('open');
        this.playGlassSound('click');
      });
    }
  }

  updateClock() {
    const clock = document.getElementById('statusTime');
    if (!clock) return;
    const now = new Date();
    const h = now.getHours().toString().padStart(2, '0');
    const m = now.getMinutes().toString().padStart(2, '0');
    clock.textContent = `${h}:${m}`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.tikTokApp = new TikTokVision26();
});
