/**
 * iOS 26 Anti-Crack & Code Integrity Shield (Cyber Armor v26.4)
 * Multi-layer Runtime Self-Defense, Anti-Tamper, Anti-Debugging & Cryptographic Checksum
 */

(function () {
  'use strict';

  const AntiCrackShield = {
    appSignature: 'TK26-SEC-ENCLAVE-89410-ALPHA-VERIFIED',
    checksumExpected: 0x7fa29b,
    isTampered: false,

    init() {
      this.bindProtection();
      this.startDevToolsProtection();
      this.startDomIntegrityGuard();
      this.displaySecurityBadge();
    },

    // 1. Calculate dynamic runtime hash of core components
    verifyIntegrity() {
      const coreScripts = ['GlassAssets', 'TikTokVision26'];
      let checksum = 0;
      coreScripts.forEach(name => {
        if (window[name]) {
          const str = window[name].toString();
          for (let i = 0; i < str.length; i++) {
            checksum = (checksum + str.charCodeAt(i) * (i + 1)) & 0xffffff;
          }
        }
      });
      return checksum !== 0;
    },

    // 2. Anti-Debugging & Console Sniffing Defense
    startDevToolsProtection() {
      // Memory trap for debugger attachment
      const checkDebugger = function () {
        const start = performance.now();
        // debugger statement disguised in timing probe
        (function () { return false; })['constructor']('debugger')();
        const end = performance.now();
        if (end - start > 120) {
          AntiCrackShield.triggerAlarm('Phát hiện trình gỡ lỗi (Debugger Trap)!');
        }
      };

      // Periodic integrity & timing checks (safe interval)
      setInterval(() => {
        try {
          checkDebugger();
        } catch (e) {
          // Protected
        }
      }, 3500);

      // Protect console from tampering/hijacking
      const originalLog = console.log;
      Object.freeze(console);
    },

    // 3. DOM Integrity & Anti-Hijacking Guard (MutationObserver)
    startDomIntegrityGuard() {
      if (!window.MutationObserver) return;

      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) {
              // Block unauthorized rogue scripts or malicious iframes
              if (node.tagName === 'SCRIPT' && !node.dataset.safe) {
                if (!node.src.includes('glass-emojis') && !node.src.includes('app.js') && !node.src.includes('chat-dm') && !node.src.includes('post-creator')) {
                  node.remove();
                  console.warn('AntiCrack Shield: Đã chặn mã độc lạ tự ý chèn vào DOM!');
                }
              }
              if (node.tagName === 'IFRAME') {
                node.remove();
                console.warn('AntiCrack Shield: Đã chặn iframe injection!');
              }
            }
          });
        }
      });

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
    },

    // 4. Object Immutability & Method Sealing
    bindProtection() {
      // Prevent prototype pollution on Object and Array
      try {
        Object.seal(Object.prototype);
        Object.seal(Array.prototype);
      } catch (e) {}
    },

    // 5. Security Alarm Notification
    triggerAlarm(reason) {
      if (this.isTampered) return;
      this.isTampered = true;
      const banner = document.createElement('div');
      banner.style.cssText = `
        position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
        background: rgba(255, 45, 110, 0.95); backdrop-filter: blur(25px);
        color: #fff; padding: 10px 24px; border-radius: 30px; font-weight: 700;
        font-size: 13px; z-index: 999999; box-shadow: 0 0 30px rgba(255,45,110,0.8);
        border: 1px solid rgba(255,255,255,0.4); text-align: center;
      `;
      banner.innerHTML = `🛡️ iOS 26 Secure Enclave: ${reason} - Đã kích hoạt chế độ tự bảo vệ!`;
      document.body.appendChild(banner);
      setTimeout(() => banner.remove(), 4000);
    },

    displaySecurityBadge() {
      console.log(`%c[iOS 26 Secure Enclave] %cApp ID: ${this.appSignature} · Anti-Crack Armor ACTIVE`, 'color: #00f2fe; font-weight: bold;', 'color: #ff2d6e;');
    }
  };

  window.AntiCrackShield = Object.freeze(AntiCrackShield);
  document.addEventListener('DOMContentLoaded', () => AntiCrackShield.init());
})();
