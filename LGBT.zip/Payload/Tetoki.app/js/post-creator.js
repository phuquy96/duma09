/**
 * iOS 26 Post Creator & Music Mixing Studio (TikTok Vision 26)
 * Real Image/Video Upload, Music Selector, Filters, and Feed Publishing
 */

class PostCreatorStudio {
  constructor() {
    this.musicLibrary = [
      { id: 1, title: 'Cyber Tokyo Rain Vibes', artist: 'Synthwave 2026 (Spatial)', duration: '0:30', freq: 440 },
      { id: 2, title: 'iOS 26 Soundscape', artist: 'Liquid Crystal Audio', duration: '0:45', freq: 523 },
      { id: 3, title: 'Neon Beat Bass Drop', artist: 'DJ Spatial Tokyo', duration: '0:28', freq: 330 },
      { id: 4, title: 'Hyperdrive', artist: 'Nightfall Spatial Audio', duration: '0:35', freq: 659 },
      { id: 5, title: 'Em Của Ngày Hôm Qua (Spatial Glass Remix)', artist: 'M-TP 2026 Remaster', duration: '0:40', freq: 392 }
    ];

    this.selectedMusic = this.musicLibrary[0];
    this.selectedFilter = 'normal';
    this.uploadedMediaUrl = 'assets/tiktok_video_cyber_tokyo_1790520635648.jpg';
    this.uploadedMediaType = 'image';

    this.init();
  }

  init() {
    this.renderMusicLibrary();
    this.setupEventListeners();
  }

  renderMusicLibrary() {
    const list = document.getElementById('musicSelectorList');
    if (!list) return;

    list.innerHTML = this.musicLibrary.map(m => `
      <div class="music-track-item ${m.id === this.selectedMusic.id ? 'active' : ''}" data-music-id="${m.id}">
        <div class="music-track-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M9 18V5L21 3V16" stroke="#00f2fe" stroke-width="2"/>
            <circle cx="6" cy="18" r="3" fill="#00f2fe"/>
            <circle cx="18" cy="16" r="3" fill="#00f2fe"/>
          </svg>
        </div>
        <div class="music-track-info">
          <div class="music-track-title">${m.title}</div>
          <div class="music-track-artist">${m.artist} · ${m.duration}</div>
        </div>
        <button class="music-play-preview-btn" onclick="window.postStudio.previewMusic(${m.id}, event)">
          ▶ Nghe thử
        </button>
      </div>
    `).join('');
  }

  previewMusic(musicId, event) {
    if (event) event.stopPropagation();
    const track = this.musicLibrary.find(m => m.id === musicId);
    if (!track) return;

    this.selectedMusic = track;
    this.renderMusicLibrary();
    this.updateSelectedMusicBadge();

    if (window.tikTokApp) {
      window.tikTokApp.playGlassSound('heart');
    }
  }

  updateSelectedMusicBadge() {
    const badge = document.getElementById('studioSelectedMusicBadge');
    if (badge) {
      badge.textContent = `♫ ${this.selectedMusic.title} - ${this.selectedMusic.artist}`;
    }
  }

  openStudio() {
    const studio = document.getElementById('postCreatorModal');
    if (studio) {
      studio.classList.add('open');
      if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
    }
  }

  closeStudio() {
    const studio = document.getElementById('postCreatorModal');
    if (studio) {
      studio.classList.remove('open');
      if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
    }
  }

  setupEventListeners() {
    // Open studio from Create (+) button
    const openBtn = document.getElementById('btnOpenPostStudio');
    if (openBtn) openBtn.addEventListener('click', () => this.openStudio());

    const closeBtn = document.getElementById('closePostStudioBtn');
    if (closeBtn) closeBtn.addEventListener('click', () => this.closeStudio());

    // File Upload handling (real photo / video)
    const fileInput = document.getElementById('studioFileInput');
    const uploadTrigger = document.getElementById('studioUploadTrigger');
    const previewImg = document.getElementById('studioPreviewImg');
    const previewVideo = document.getElementById('studioPreviewVideo');

    if (uploadTrigger && fileInput) {
      uploadTrigger.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const url = URL.createObjectURL(file);
        this.uploadedMediaUrl = url;

        if (file.type.startsWith('video/')) {
          this.uploadedMediaType = 'video';
          if (previewVideo) {
            previewVideo.src = url;
            previewVideo.style.display = 'block';
            previewVideo.play();
          }
          if (previewImg) previewImg.style.display = 'none';
        } else {
          this.uploadedMediaType = 'image';
          if (previewImg) {
            previewImg.src = url;
            previewImg.style.display = 'block';
          }
          if (previewVideo) previewVideo.style.display = 'none';
        }

        if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
      });
    }

    // Music Sheet Trigger
    const musicSheetBtn = document.getElementById('btnOpenMusicSheet');
    const musicSheet = document.getElementById('musicSheetModal');
    const closeMusicBtn = document.getElementById('closeMusicSheetBtn');

    if (musicSheetBtn && musicSheet) {
      musicSheetBtn.addEventListener('click', () => {
        musicSheet.classList.add('open');
        document.getElementById('sheetBackdrop').classList.add('open');
        if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
      });
    }

    if (closeMusicBtn && musicSheet) {
      closeMusicBtn.addEventListener('click', () => {
        musicSheet.classList.remove('open');
        document.getElementById('sheetBackdrop').classList.remove('open');
        this.updateSelectedMusicBadge();
        if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
      });
    }

    // Filter Chips
    const filterChips = document.querySelectorAll('.studio-filter-chip');
    filterChips.forEach(chip => {
      chip.addEventListener('click', () => {
        filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        this.selectedFilter = chip.dataset.filter;

        const previewContainer = document.getElementById('studioPreviewContainer');
        if (previewContainer) {
          previewContainer.className = `studio-preview-box filter-${this.selectedFilter}`;
        }
        if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
      });
    });

    // Hashtag Chips click
    const tagChips = document.querySelectorAll('.studio-tag-chip');
    const captionInput = document.getElementById('studioCaptionInput');
    tagChips.forEach(tag => {
      tag.addEventListener('click', () => {
        if (captionInput) {
          captionInput.value += ' ' + tag.textContent;
          captionInput.focus();
        }
      });
    });

    // Publish Post button
    const publishBtn = document.getElementById('studioPublishBtn');
    if (publishBtn) {
      publishBtn.addEventListener('click', () => this.publishNewPost());
    }
  }

  publishNewPost() {
    const captionInput = document.getElementById('studioCaptionInput');
    const caption = captionInput && captionInput.value.trim() ? captionInput.value.trim() : 'Khoảnh khắc tuyệt đẹp với giao diện iOS 26 Glass! ✨💎';

    // Show upload progress on Dynamic Island
    const island = document.getElementById('dynamicIsland');
    const label = document.getElementById('islandLabel');
    if (island && label) {
      island.classList.add('expanded');
      label.innerHTML = `⚡ Đang xuất bản video iOS 26... 100%`;
    }

    if (window.tikTokApp) {
      window.tikTokApp.playGlassSound('heart');
    }

    // Insert new post into app.videos at top
    const newVideo = {
      id: Date.now(),
      author: 'ban_la_nhat_2026',
      name: 'Bạn (Creator 26) ✦',
      avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
      bg: this.uploadedMediaUrl,
      caption: caption,
      tags: ['#NewPost', '#iOS26', '#TikTokVision', '#GlassVibe'],
      music: `♫ ${this.selectedMusic.title} - ${this.selectedMusic.artist}`,
      likes: 1,
      comments: 0,
      bookmarks: 0,
      shares: 0,
      liked: true,
      bookmarked: false,
      followed: false,
      hasCanvasFX: 'particles'
    };

    if (window.tikTokApp) {
      window.tikTokApp.videos.unshift(newVideo);
      window.tikTokApp.currentIndex = 0;
      window.tikTokApp.renderFeed();
      
      const feed = document.getElementById('tiktokFeed');
      if (feed) feed.scrollTo({ top: 0, behavior: 'smooth' });
    }

    this.closeStudio();

    setTimeout(() => {
      if (island) island.classList.remove('expanded');
      alert('🎉 Chúc mừng! Video của bạn đã được đăng thành công lên đầu bảng tin TikTok Vision 26!');
    }, 1200);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.postStudio = new PostCreatorStudio();
});
