/**
 * Tetoki iOS 26 Liquid Glass Authentication & Account Engine
 * Admin Account: PHUQUY / PHUQUY17
 * Face ID Biometric Scan, Account Creation & Session Persistence
 */

class TetokiAuthEngine {
  constructor() {
    this.currentUser = null;
    this.defaultAvatar = 'assets/app_icon_tetoki.png';
    
    // Dedicated Master Admin Credentials
    this.adminCredentials = {
      username: 'PHUQUY',
      password: 'PHUQUY17',
      profile: {
        name: 'PHÚ QUÝ (ADMIN VIP ✦)',
        username: 'PHUQUY',
        avatar: 'assets/app_icon_tetoki.png',
        isAdmin: true,
        bio: '👑 Chủ Sở Hữu & Quản Trị Viên Tối Cao Tetoki · iOS 26 Executive',
        followers: '99.9M',
        following: '1',
        likes: '888M',
        createdDate: '27/09/2026'
      }
    };

    this.init();
  }

  init() {
    this.loadUserSession();
    this.setupEventListeners();
  }

  loadUserSession() {
    const saved = localStorage.getItem('tetoki_current_user');
    if (saved) {
      try {
        this.currentUser = JSON.parse(saved);
        this.applyUserToApp(this.currentUser);
        this.hideAuthGate(false);
        return;
      } catch (e) {}
    }
    // Not logged in -> Show Auth Gate immediately
    this.showAuthGate();
  }

  showAuthGate() {
    const modal = document.getElementById('tetokiAuthGateModal');
    if (modal) {
      modal.classList.add('active');
    }
  }

  hideAuthGate(animate = true) {
    const modal = document.getElementById('tetokiAuthGateModal');
    if (!modal) return;
    if (animate) {
      modal.style.transition = 'all 0.5s cubic-bezier(0.16, 1, 0.3, 1)';
      modal.style.opacity = '0';
      modal.style.transform = 'scale(1.08)';
      setTimeout(() => {
        modal.classList.remove('active');
        modal.style.opacity = '';
        modal.style.transform = '';
      }, 500);
    } else {
      modal.classList.remove('active');
    }
  }

  setupEventListeners() {
    // Tab switching: Đăng ký vs Đăng nhập
    const tabRegister = document.getElementById('authTabRegister');
    const tabLogin = document.getElementById('authTabLogin');
    const formRegister = document.getElementById('authFormRegister');
    const formLogin = document.getElementById('authFormLogin');

    if (tabRegister && tabLogin) {
      tabRegister.addEventListener('click', () => {
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        formRegister.style.display = 'flex';
        formLogin.style.display = 'none';
        if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
      });

      tabLogin.addEventListener('click', () => {
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        formLogin.style.display = 'flex';
        formRegister.style.display = 'none';
        if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
      });
    }

    // Quick Admin Login Fill Button
    const btnQuickAdmin = document.getElementById('btnQuickAdminLogin');
    if (btnQuickAdmin) {
      btnQuickAdmin.addEventListener('click', () => {
        const u = document.getElementById('loginUsernameInput');
        const p = document.getElementById('loginPasswordInput');
        if (u) u.value = 'PHUQUY';
        if (p) p.value = 'PHUQUY17';
        if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
        this.handleLogin();
      });
    }

    // Avatar upload preview in register form
    const avatarInput = document.getElementById('regAvatarInput');
    const avatarPreview = document.getElementById('regAvatarPreview');
    const avatarBox = document.getElementById('regAvatarBox');

    if (avatarBox && avatarInput) {
      avatarBox.addEventListener('click', () => avatarInput.click());
      avatarInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => {
            avatarPreview.src = ev.target.result;
            if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
          };
          reader.readAsDataURL(file);
        }
      });
    }

    // Submit Register
    const btnSubmitRegister = document.getElementById('btnSubmitRegister');
    if (btnSubmitRegister) {
      btnSubmitRegister.addEventListener('click', () => this.handleRegister());
    }

    // Submit Login
    const btnSubmitLogin = document.getElementById('btnSubmitLogin');
    if (btnSubmitLogin) {
      btnSubmitLogin.addEventListener('click', () => this.handleLogin());
    }

    // Face ID Quick Scan
    const btnFaceId = document.getElementById('btnFaceIdScan');
    if (btnFaceId) {
      btnFaceId.addEventListener('click', () => this.handleFaceIdLogin());
    }
  }

  handleRegister() {
    const nameInput = document.getElementById('regNameInput');
    const usernameInput = document.getElementById('regUsernameInput');
    const passwordInput = document.getElementById('regPasswordInput');
    const avatarPreview = document.getElementById('regAvatarPreview');

    const name = nameInput ? nameInput.value.trim() : '';
    let username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value.trim() : '';
    const avatar = avatarPreview && avatarPreview.src ? avatarPreview.src : this.defaultAvatar;

    if (!name || !username || !password) {
      alert('Vui lòng nhập đầy đủ Tên, Tên người dùng (@) và Mật khẩu!');
      return;
    }

    username = username.replace(/^@/, '');

    const newUser = {
      name: name,
      username: username,
      avatar: avatar,
      bio: 'Người dùng Tetoki VIP · iOS 26 Liquid Glass',
      followers: '1.2K',
      following: '84',
      likes: '14.8K',
      createdDate: new Date().toLocaleDateString('vi-VN')
    };

    localStorage.setItem('tetoki_current_user', JSON.stringify(newUser));
    this.currentUser = newUser;

    if (window.tikTokApp) window.tikTokApp.playGlassSound('heart');
    this.triggerWelcomeSequence(newUser);
  }

  handleLogin() {
    const usernameInput = document.getElementById('loginUsernameInput');
    const passwordInput = document.getElementById('loginPasswordInput');

    const username = usernameInput ? usernameInput.value.trim().replace(/^@/, '') : '';
    const password = passwordInput ? passwordInput.value.trim() : '';

    if (!username || !password) {
      alert('Vui lòng nhập Tên tài khoản và Mật khẩu!');
      return;
    }

    // Check Master Admin Account (PHUQUY / PHUQUY17)
    if (username.toUpperCase() === this.adminCredentials.username && password === this.adminCredentials.password) {
      const adminUser = this.adminCredentials.profile;
      localStorage.setItem('tetoki_current_user', JSON.stringify(adminUser));
      this.currentUser = adminUser;
      if (window.tikTokApp) window.tikTokApp.playGlassSound('heart');
      this.triggerWelcomeSequence(adminUser);
      return;
    }

    // Check custom saved user
    const saved = localStorage.getItem('tetoki_current_user');
    let user;
    if (saved) {
      try {
        const savedUser = JSON.parse(saved);
        if (savedUser.username.toLowerCase() === username.toLowerCase()) {
          user = savedUser;
        }
      } catch (e) {}
    }

    if (!user) {
      user = {
        name: username.toUpperCase() + ' ✦',
        username: username,
        avatar: this.defaultAvatar,
        bio: 'Tetoki VIP Member · iOS 26',
        followers: '3.4K',
        following: '180',
        likes: '42.1K'
      };
    }

    localStorage.setItem('tetoki_current_user', JSON.stringify(user));
    this.currentUser = user;

    if (window.tikTokApp) window.tikTokApp.playGlassSound('heart');
    this.triggerWelcomeSequence(user);
  }

  handleFaceIdLogin() {
    const faceRing = document.getElementById('faceIdScannerRing');
    const faceStatus = document.getElementById('faceIdStatusText');

    if (faceRing) faceRing.classList.add('scanning');
    if (faceStatus) faceStatus.textContent = 'Đang quét sinh trắc học Face ID...';
    if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');

    setTimeout(() => {
      if (faceRing) {
        faceRing.classList.remove('scanning');
        faceRing.classList.add('success');
      }
      if (faceStatus) faceStatus.textContent = 'Xác thực Face ID Thành Công!';
      if (window.tikTokApp) window.tikTokApp.playGlassSound('heart');

      // Auto login as admin PHUQUY on Face ID
      const user = this.adminCredentials.profile;
      localStorage.setItem('tetoki_current_user', JSON.stringify(user));
      this.currentUser = user;

      setTimeout(() => this.triggerWelcomeSequence(user), 600);
    }, 1300);
  }

  triggerWelcomeSequence(user) {
    this.applyUserToApp(user);
    this.hideAuthGate(true);

    const island = document.getElementById('dynamicIsland');
    const label = document.getElementById('islandLabel');
    if (island && label) {
      island.classList.add('expanded');
      label.innerHTML = user.isAdmin ? 
        `👑 <strong>ADMIN PHÚ QUÝ</strong> Đã Đăng Nhập!` : 
        `👋 Chào mừng <strong>@${user.username}</strong>!`;
      setTimeout(() => {
        island.classList.remove('expanded');
        if (window.tikTokApp) window.tikTokApp.updateDynamicIslandForCurrentVideo();
      }, 3500);
    }
  }

  applyUserToApp(user) {
    if (!user) return;

    // Update Profile View
    const profileName = document.querySelector('#profileTabView .profile-name');
    const profileHandle = document.querySelector('#profileTabView .profile-hero div[style*="font-size:12px"]');
    const profileAvatar = document.querySelector('#profileTabView .profile-avatar-big');
    const statFollowers = document.querySelector('#profileTabView .profile-stat-box:nth-child(2) .stat-number');
    const statFollowing = document.querySelector('#profileTabView .profile-stat-box:nth-child(1) .stat-number');
    const statLikes = document.querySelector('#profileTabView .profile-stat-box:nth-child(3) .stat-number');

    if (profileName) {
      profileName.innerHTML = `${user.name} <span class="verified-glass-badge">✓</span>`;
    }
    if (profileHandle) {
      profileHandle.textContent = `@${user.username} · ${user.bio || 'Tetoki Creator'}`;
    }
    if (profileAvatar) {
      profileAvatar.src = user.avatar || this.defaultAvatar;
    }
    if (statFollowers && user.followers) statFollowers.textContent = user.followers;
    if (statFollowing && user.following) statFollowing.textContent = user.following;
    if (statLikes && user.likes) statLikes.textContent = user.likes;

    // Update Stories
    const myStoryAvatar = document.querySelector('#storiesTray .story-item:first-child .story-avatar-img');
    if (myStoryAvatar) myStoryAvatar.src = user.avatar || this.defaultAvatar;

    // Update Post Studio creator
    if (window.postStudio) {
      window.postStudio.currentUser = user;
    }
  }

  logout() {
    localStorage.removeItem('tetoki_current_user');
    this.currentUser = null;
    this.showAuthGate();
    if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.tetokiAuth = new TetokiAuthEngine();
});
