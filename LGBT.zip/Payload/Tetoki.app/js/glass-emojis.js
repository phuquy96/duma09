/**
 * Glass Emojis & Handcrafted SVG Vector Assets for Tetoki (TikTok Vision 26)
 * 100% Custom Hand-Crafted 3D Vector Glass Emojis & Icons
 * ZERO generic icons or standard unicode font emojis used!
 */

const GlassAssets = {
  // Global SVG Filters & Gradients
  getSvgDefs() {
    return `
      <svg width="0" height="0" style="position:absolute;visibility:hidden;pointer-events:none;">
        <defs>
          <!-- iOS 26 Glass Caustic Specular Filter -->
          <filter id="ios26-specular" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="2" result="blur"/>
            <feSpecularLighting in="blur" surfaceScale="5" specularConstant="1.4" specularExponent="30" lighting-color="#ffffff" result="specOut">
              <fePointLight x="-15" y="-20" z="40"/>
            </feSpecularLighting>
            <feComposite in="specOut" in2="SourceAlpha" operator="in" result="specIn"/>
            <feComposite in="SourceGraphic" in2="specIn" operator="arithmetic" k1="0" k2="1" k3="1" k4="0"/>
          </filter>

          <!-- Chromatic Aberration Rim Glow -->
          <filter id="ios26-rim-glow" x="-40%" y="-40%" width="180%" height="180%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="rgba(0, 242, 254, 0.45)"/>
            <feDropShadow dx="0" dy="-2" stdDeviation="2.5" flood-color="rgba(255, 45, 110, 0.4)"/>
          </filter>

          <!-- Gradients -->
          <linearGradient id="glass-heart-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#ff2d6e" stop-opacity="0.95"/>
            <stop offset="50%" stop-color="#ff0055" stop-opacity="0.85"/>
            <stop offset="100%" stop-color="#990033" stop-opacity="0.9"/>
          </linearGradient>

          <linearGradient id="glass-heart-inactive" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="rgba(255,255,255,0.95)"/>
            <stop offset="50%" stop-color="rgba(235,240,255,0.7)"/>
            <stop offset="100%" stop-color="rgba(190,205,230,0.5)"/>
          </linearGradient>

          <linearGradient id="glass-sheen" x1="0%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stop-color="rgba(255,255,255,0.95)"/>
            <stop offset="35%" stop-color="rgba(255,255,255,0.4)"/>
            <stop offset="100%" stop-color="rgba(255,255,255,0)"/>
          </linearGradient>

          <linearGradient id="glass-cyan-blue" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#00f2fe"/>
            <stop offset="50%" stop-color="#4facfe"/>
            <stop offset="100%" stop-color="#0066fe"/>
          </linearGradient>

          <linearGradient id="glass-gold-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FFE066"/>
            <stop offset="40%" stop-color="#FFAA00"/>
            <stop offset="100%" stop-color="#FF7700"/>
          </linearGradient>

          <linearGradient id="glass-fire-grad" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stop-color="#ff1744" stop-opacity="0.95"/>
            <stop offset="45%" stop-color="#ff9100" stop-opacity="0.9"/>
            <stop offset="85%" stop-color="#ffea00" stop-opacity="0.95"/>
            <stop offset="100%" stop-color="#ffffff" stop-opacity="0.95"/>
          </linearGradient>

          <radialGradient id="glass-sphere-body" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stop-color="#fff8e1" stop-opacity="0.95"/>
            <stop offset="35%" stop-color="#ffca28" stop-opacity="0.85"/>
            <stop offset="75%" stop-color="#ff8f00" stop-opacity="0.9"/>
            <stop offset="100%" stop-color="#c43e00" stop-opacity="0.95"/>
          </radialGradient>

          <radialGradient id="glass-cosmic-body" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stop-color="#e0f7fa" stop-opacity="0.95"/>
            <stop offset="40%" stop-color="#80deea" stop-opacity="0.85"/>
            <stop offset="80%" stop-color="#7c4dff" stop-opacity="0.9"/>
            <stop offset="100%" stop-color="#311b92" stop-opacity="0.95"/>
          </radialGradient>

          <linearGradient id="glass-tear-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#00e5ff" stop-opacity="0.95"/>
            <stop offset="60%" stop-color="#0091ea" stop-opacity="0.85"/>
            <stop offset="100%" stop-color="#01579b" stop-opacity="0.95"/>
          </linearGradient>

          <linearGradient id="glass-hologram" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#00f2fe"/>
            <stop offset="50%" stop-color="#4facfe"/>
            <stop offset="100%" stop-color="#9b51e0"/>
          </linearGradient>
        </defs>
      </svg>
    `;
  },

  // 1. Handcrafted 3D Glass Crystal Heart
  getGlassHeart(active = false, size = 36) {
    const fill = active ? 'url(#glass-heart-grad)' : 'url(#glass-heart-inactive)';
    const glow = active ? 'filter: drop-shadow(0 0 14px rgba(255, 45, 110, 0.85));' : 'filter: drop-shadow(0 4px 10px rgba(0,0,0,0.35));';
    return `
      <svg class="glass-svg-icon ${active ? 'active-pulse' : ''}" style="${glow}" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none">
        <path d="M24 41.5C23.2 41.5 8 29.5 5.5 20C3.2 11.2 9.5 5 17 5C20.6 5 23 7.5 24 9C25 7.5 27.4 5 31 5C38.5 5 44.8 11.2 42.5 20C40 29.5 24.8 41.5 24 41.5Z" 
              fill="${fill}" opacity="0.95"/>
        <path d="M24 38C23.4 38 10 27.5 7.8 19.5C5.8 12 11 6.8 17 6.8C20 6.8 22.4 8.5 24 10.5C25.6 8.5 28 6.8 31 6.8C37 6.8 42.2 12 40.2 19.5C38 27.5 24.6 38 24 38Z" 
              fill="rgba(255,255,255,0.18)"/>
        <path d="M12 9C9 12 8 16 9.5 19.5C8 16.5 9 12 12.5 8C14.5 5.7 18 5.5 20 6.2C17 6.2 14 7 12 9Z" 
              fill="url(#glass-sheen)"/>
        <path d="M24 40.5C23.5 40.5 9 28.5 6.7 19.5C4.7 11.5 10.5 5.8 17 5.8C20.4 5.8 22.8 7.8 24 9.5C25.2 7.8 27.6 5.8 31 5.8C37.5 5.8 43.3 11.5 41.3 19.5C39 28.5 24.5 40.5 24 40.5Z" 
              stroke="rgba(255, 255, 255, 0.8)" stroke-width="1.2" stroke-linecap="round"/>
        <circle cx="15" cy="14" r="1.8" fill="#ffffff" opacity="0.9"/>
        <circle cx="33" cy="15" r="1.2" fill="#ffffff" opacity="0.8"/>
      </svg>
    `;
  },

  // 2. Handcrafted 3D Glass Fire / Flame Emoji
  getGlassFlame(size = 30) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 0 10px rgba(255, 120, 0, 0.6));">
        <path d="M24 3C24 3 35 15 35 27C35 34.5 29.5 42 22 43C29 37 27 28 22 23C21 28 17 31 16 34C13.5 30 13 25 15 21C11 25.5 9 30 9 35C9 39 12 43 18 44C8 42 4 33 6 25C8 17 17 11 24 3Z" 
              fill="url(#glass-fire-grad)" opacity="0.9"/>
        <path d="M23 16C23 16 30 24 29 31C28.5 35 25 38 21 38.5C24.5 35 24 30 21 26C20 29 18 31 17 33C15 30 15 27 16 25C14 27.5 13.5 30 14 32.5C12 28 14 23 18 19C20.5 16.5 22 17 23 16Z" 
              fill="#ffffff" opacity="0.88"/>
        <path d="M24 5C28 12 33 20 33 27C33 32 30 36 27 38" 
              stroke="rgba(255,255,255,0.75)" stroke-width="1.2" stroke-linecap="round"/>
      </svg>
    `;
  },

  // 3. Handcrafted 3D Glass Laughing Tears Emoji (Cry-Joy)
  getGlassLaughTears(size = 30) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 0 10px rgba(255, 180, 0, 0.5));">
        <circle cx="24" cy="24" r="20" fill="url(#glass-sphere-body)"/>
        <ellipse cx="20" cy="13" rx="10" ry="5" fill="url(#glass-sheen)"/>
        <circle cx="24" cy="24" r="19.5" stroke="rgba(255,255,255,0.6)" stroke-width="1"/>
        <path d="M12 21C14 17 18 17 20 21" stroke="#4a1500" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M28 21C30 17 34 17 36 21" stroke="#4a1500" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M15 26C15 26 18 36 24 36C30 36 33 26 33 26C33 26 24 28 15 26Z" fill="#3e1300"/>
        <path d="M17 26.5C19 28.5 29 28.5 31 26.5" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
        <path d="M7 23C7 23 3 27 3 30C3 33 5.5 34.5 7.5 34.5C9.5 34.5 12 33 12 30C12 27 7 23 7 23Z" 
              fill="url(#glass-tear-grad)" opacity="0.95" style="filter: drop-shadow(0 2px 6px rgba(0, 180, 255, 0.7));"/>
        <circle cx="6.5" cy="29" r="1.2" fill="#ffffff"/>
        <path d="M41 23C41 23 45 27 45 30C45 33 42.5 34.5 40.5 34.5C38.5 34.5 36 33 36 30C36 27 41 23 41 23Z" 
              fill="url(#glass-tear-grad)" opacity="0.95" style="filter: drop-shadow(0 2px 6px rgba(0, 180, 255, 0.7));"/>
        <circle cx="41.5" cy="29" r="1.2" fill="#ffffff"/>
      </svg>
    `;
  },

  // 4. Handcrafted 3D Glass Star-Struck Emoji (Diamond Star Eyes)
  getGlassStarStruck(size = 30) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 0 12px rgba(255, 200, 50, 0.6));">
        <circle cx="24" cy="24" r="20" fill="url(#glass-sphere-body)"/>
        <ellipse cx="20" cy="13" rx="10" ry="5" fill="url(#glass-sheen)"/>
        <circle cx="24" cy="24" r="19.5" stroke="rgba(255,255,255,0.7)" stroke-width="1"/>
        <g transform="translate(16, 19)">
          <path d="M0 -6 L1.5 -1.5 L6 0 L1.5 1.5 L0 6 L-1.5 1.5 L-6 0 L-1.5 -1.5 Z" fill="#ffffff" style="filter: drop-shadow(0 0 5px #00ffff);"/>
          <circle cx="0" cy="0" r="1.5" fill="#00f2fe"/>
        </g>
        <g transform="translate(32, 19)">
          <path d="M0 -6 L1.5 -1.5 L6 0 L1.5 1.5 L0 6 L-1.5 1.5 L-6 0 L-1.5 -1.5 Z" fill="#ffffff" style="filter: drop-shadow(0 0 5px #00ffff);"/>
          <circle cx="0" cy="0" r="1.5" fill="#00f2fe"/>
        </g>
        <path d="M15 28C16 35 32 35 33 28C33 28 24 31 15 28Z" fill="#3a1000"/>
        <path d="M17 28.5C20 31 28 31 31 28.5" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
        <circle cx="12" cy="28" r="3" fill="#ff4081" opacity="0.45"/>
        <circle cx="36" cy="28" r="3" fill="#ff4081" opacity="0.45"/>
      </svg>
    `;
  },

  // 5. Handcrafted 3D Glass Mind-Blown Emoji
  getGlassMindBlown(size = 30) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 0 14px rgba(124, 77, 255, 0.7));">
        <path d="M12 12C10 6 22 2 24 6C27 1 38 6 36 12C41 12 43 17 38 20C34 22 14 22 10 20C5 17 7 12 12 12Z" 
              fill="url(#glass-hologram)" opacity="0.9" style="filter: drop-shadow(0 0 8px #ff4081);"/>
        <polygon points="18,3 20,7 16,6" fill="#ffffff"/>
        <polygon points="28,2 30,5 26,4" fill="#00ffff"/>
        <polygon points="24,0 25,3 23,3" fill="#ffea00"/>
        <path d="M8 20C8 30 15 39 24 39C33 39 40 30 40 20C36 21 12 21 8 20Z" fill="url(#glass-cosmic-body)"/>
        <circle cx="24" cy="28" r="15.5" stroke="rgba(255,255,255,0.5)" stroke-width="1"/>
        <circle cx="18" cy="25" r="4" fill="#ffffff"/>
        <circle cx="18" cy="25" r="2" fill="#1a237e"/>
        <circle cx="30" cy="25" r="4" fill="#ffffff"/>
        <circle cx="30" cy="25" r="2" fill="#1a237e"/>
        <ellipse cx="24" cy="33" rx="3" ry="4" fill="#0d47a1"/>
      </svg>
    `;
  },

  // 6. Handcrafted 3D Glass Thumbs-Up
  getGlassThumbsUp(size = 30) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.6));">
        <path d="M19 19L19 9C19 6.5 21 4 23 4C24.5 4 25.5 5.5 25.5 7L25 15L34 15C36.8 15 39 17.2 39 20C39 21.2 38.5 22.3 37.8 23C38.8 24 39.2 25.2 39.2 26.5C39.2 27.6 38.6 28.6 37.7 29.3C38.4 30.2 38.7 31.4 38.7 32.5C38.7 35.3 36.5 37 34 37L22 37C19.5 37 17 35.5 16 33.5L13 27L13 19L19 19Z" 
              fill="url(#glass-hologram)" opacity="0.92"/>
        <rect x="7" y="19" width="6" height="18" rx="3" fill="rgba(255,255,255,0.7)"/>
        <path d="M22 6C23 6 24 7 24 9L23.5 17L33 17" stroke="rgba(255,255,255,0.85)" stroke-width="1.2" stroke-linecap="round"/>
        <path d="M7 19L13 19L13 37L7 37Z" stroke="rgba(255,255,255,0.85)" stroke-width="1"/>
      </svg>
    `;
  },

  // 7. Handcrafted 3D Glass Comments Icon
  getGlassComment(size = 36) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 4px 10px rgba(0,0,0,0.35));">
        <path d="M24 6C13.5 6 5 13.6 5 23C5 27.2 6.8 31 10 33.8L8 41L15.8 38.4C18.3 39.4 21.1 40 24 40C34.5 40 43 32.4 43 23C43 13.6 34.5 6 24 6Z" 
              fill="url(#glass-heart-inactive)" opacity="0.92"/>
        <path d="M24 8C14.6 8 7 14.7 7 23C7 26.8 8.6 30.2 11.5 32.7L9.9 38.3L16.2 36.2C18.5 37.3 21.2 38 24 38C33.4 38 41 31.3 41 23C41 14.7 33.4 8 24 8Z" 
              stroke="rgba(255, 255, 255, 0.8)" stroke-width="1.2"/>
        <path d="M12 12C15 9 19.5 8 24 8C28.5 8 33 9 36 12C33 10.5 28.5 10 24 10C19.5 10 15 10.5 12 12Z" 
              fill="url(#glass-sheen)"/>
        <circle cx="16" cy="23" r="2.4" fill="#ffffff" style="filter: drop-shadow(0 0 4px #00ffff);"/>
        <circle cx="24" cy="23" r="2.4" fill="#ffffff" style="filter: drop-shadow(0 0 4px #00ffff);"/>
        <circle cx="32" cy="23" r="2.4" fill="#ffffff" style="filter: drop-shadow(0 0 4px #00ffff);"/>
      </svg>
    `;
  },

  // 8. Handcrafted 3D Glass Bookmark / Ribbon
  getGlassBookmark(active = false, size = 36) {
    const fill = active ? 'url(#glass-gold-grad)' : 'url(#glass-heart-inactive)';
    const glow = active ? 'filter: drop-shadow(0 0 14px rgba(255, 170, 0, 0.85));' : 'filter: drop-shadow(0 4px 10px rgba(0,0,0,0.35));';
    return `
      <svg class="glass-svg-icon ${active ? 'active-pulse' : ''}" style="${glow}" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none">
        <path d="M12 6C10.9 6 10 6.9 10 8V42L24 34L38 42V8C38 6.9 37.1 6 36 6H12Z" 
              fill="${fill}" opacity="0.92"/>
        <path d="M12 8H36V37.5L24 30.5L12 37.5V8Z" 
              fill="rgba(255,255,255,0.2)"/>
        <path d="M12 7C11.5 7 11 7.5 11 8V40.5L24 33L37 40.5V8C37 7.5 36.5 7 36 7H12Z" 
              stroke="rgba(255,255,255,0.8)" stroke-width="1.2"/>
        <path d="M14 9H34V13C30 11 18 11 14 13V9Z" fill="url(#glass-sheen)"/>
        <polygon points="24,18 25,22 29,23 25,24 24,28 23,24 19,23 23,22" fill="#ffffff" opacity="${active ? '1' : '0.75'}"/>
      </svg>
    `;
  },

  // 9. Handcrafted 3D Glass Share / Origami Jet
  getGlassShare(size = 36) {
    return `
      <svg class="glass-svg-icon" width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="filter: drop-shadow(0 4px 12px rgba(0, 229, 255, 0.45));">
        <path d="M42 6L6 22L20 27L42 6Z" fill="url(#glass-hologram)" opacity="0.95"/>
        <path d="M42 6L28 42L20 27L42 6Z" fill="url(#glass-heart-inactive)" opacity="0.8"/>
        <path d="M20 27L24 35L28 42L42 6" stroke="rgba(255,255,255,0.9)" stroke-width="1.2"/>
        <path d="M6 22L20 27L42 6L6 22Z" stroke="rgba(255,255,255,0.9)" stroke-width="1.2"/>
        <circle cx="41" cy="7" r="2.2" fill="#ffffff" style="filter: drop-shadow(0 0 6px #00ffff);"/>
      </svg>
    `;
  },

  // 10. Handcrafted 3D Holographic Vinyl Disc
  getGlassDisc(coverImg = '', size = 46) {
    return `
      <div class="glass-disc-container" style="width:${size}px; height:${size}px;">
        <svg class="glass-disc-svg spin-slow" width="${size}" height="${size}" viewBox="0 0 54 54" fill="none">
          <circle cx="27" cy="27" r="26" fill="#111115" stroke="rgba(255,255,255,0.25)" stroke-width="1"/>
          <circle cx="27" cy="27" r="22" stroke="rgba(255,255,255,0.12)" stroke-width="0.8"/>
          <circle cx="27" cy="27" r="18" stroke="rgba(0, 229, 255, 0.25)" stroke-width="0.8"/>
          <circle cx="27" cy="27" r="14" stroke="rgba(255, 45, 110, 0.25)" stroke-width="0.8"/>
          <path d="M27 27 L4 10 A26 26 0 0 1 20 2 Z" fill="rgba(255,255,255,0.15)"/>
          <path d="M27 27 L50 44 A26 26 0 0 1 34 52 Z" fill="rgba(255,255,255,0.15)"/>
          <circle cx="27" cy="27" r="8" fill="#ff2d6e" stroke="#ffffff" stroke-width="1.5"/>
          <circle cx="27" cy="27" r="3" fill="#000000"/>
        </svg>
        ${coverImg ? `<img src="${coverImg}" class="glass-disc-cover" alt="track cover">` : ''}
        <div class="glass-note note-1">♫</div>
        <div class="glass-note note-2">♪</div>
      </div>
    `;
  },

  // 11. Handcrafted 3D Glass Close Icon (✕)
  getGlassClose(size = 18) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M18 6L6 18M6 6L18 18" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="filter: drop-shadow(0 0 4px rgba(255,255,255,0.6));"/>
      </svg>
    `;
  },

  // 12. Handcrafted 3D Glass Phone Call Icon
  getGlassPhone(size = 18) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M22 16.92V19.92C22 20.48 21.54 20.94 20.97 20.91C16.14 20.66 11.66 18.68 8.04 15.36C4.72 12.04 2.74 7.56 2.49 2.73C2.46 2.16 2.92 1.7 3.48 1.7H6.48C7.03 1.7 7.48 2.15 7.48 2.7C7.48 4.2 7.78 5.65 8.35 6.98C8.5 7.33 8.41 7.73 8.13 8.01L6.75 9.39C8.36 12.33 11.07 15.04 14.01 16.65L15.39 15.27C15.67 14.99 16.07 14.9 16.42 15.05C17.75 15.62 19.2 15.92 20.7 15.92C21.25 15.92 21.7 16.37 21.7 16.92H22Z" 
              fill="url(#glass-cyan-blue)" stroke="#ffffff" stroke-width="0.8"/>
      </svg>
    `;
  },

  // 13. Handcrafted 3D Glass FaceTime / Video Icon
  getGlassVideo(size = 18) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="5" width="14" height="14" rx="4" fill="url(#glass-hologram)" stroke="#ffffff" stroke-width="0.8"/>
        <path d="M16 10L22 6V18L16 14V10Z" fill="url(#glass-hologram)" stroke="#ffffff" stroke-width="0.8"/>
        <circle cx="8" cy="11" r="2.5" fill="#ffffff" opacity="0.6"/>
      </svg>
    `;
  },

  // 14. Handcrafted 3D Glass Camera Icon
  getGlassCamera(size = 20) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M23 19C23 20.1 22.1 21 21 21H3C1.9 21 1 20.1 1 19V8C1 6.9 1.9 6 3 6H7L9 3H15L17 6H21C22.1 6 23 6.9 23 8V19Z" 
              fill="url(#glass-hologram)" stroke="#ffffff" stroke-width="0.8"/>
        <circle cx="12" cy="13" r="4.5" fill="rgba(0,0,0,0.5)" stroke="#ffffff" stroke-width="1.2"/>
        <circle cx="12" cy="13" r="2" fill="url(#glass-cyan-blue)"/>
      </svg>
    `;
  },

  // 15. Handcrafted 3D Glass Crystal Gem / Sparkle Icon
  getGlassGem(size = 20) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <polygon points="6,3 18,3 22,9 12,21 2,9" fill="url(#glass-cyan-blue)" stroke="#ffffff" stroke-width="1"/>
        <polygon points="6,3 18,3 15,9 9,9" fill="rgba(255,255,255,0.4)"/>
        <line x1="2" y1="9" x2="22" y2="9" stroke="#ffffff" stroke-width="0.8"/>
      </svg>
    `;
  },

  // 16. Handcrafted 3D Glass Folder Upload Icon
  getGlassFolderUpload(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M22 19C22 20.1 21.1 21 20 21H4C2.9 21 2 20.1 2 19V5C2 3.9 2.9 3 4 3H9L11 6H20C21.1 6 22 6.9 22 8V19Z" 
              fill="url(#glass-hologram)" opacity="0.85" stroke="#ffffff" stroke-width="0.8"/>
        <path d="M12 11V17M12 11L9 14M12 11L15 14" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  },

  // 17. Handcrafted 3D Glass AirDrop Radar Icon
  getGlassAirDrop(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="2.5" fill="#00f2fe"/>
        <path d="M8.5 8.5C10.4 6.5 13.6 6.5 15.5 8.5" stroke="#00f2fe" stroke-width="2" stroke-linecap="round"/>
        <path d="M5.5 5.5C9.1 1.9 14.9 1.9 18.5 5.5" stroke="#4facfe" stroke-width="2" stroke-linecap="round"/>
        <path d="M8.5 15.5C10.4 17.5 13.6 17.5 15.5 15.5" stroke="#00f2fe" stroke-width="2" stroke-linecap="round"/>
        <path d="M5.5 18.5C9.1 22.1 14.9 22.1 18.5 18.5" stroke="#4facfe" stroke-width="2" stroke-linecap="round"/>
      </svg>
    `;
  },

  // 18. Handcrafted 3D Glass Link Chain Icon
  getGlassLink(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M10 13A5 5 0 0 0 17.07 14.07L20.07 11.07A5 5 0 0 0 13 4L11.5 5.5" stroke="url(#glass-cyan-blue)" stroke-width="2.2" stroke-linecap="round"/>
        <path d="M14 11A5 5 0 0 0 6.93 9.93L3.93 12.93A5 5 0 0 0 11 20L12.5 18.5" stroke="url(#glass-heart-grad)" stroke-width="2.2" stroke-linecap="round"/>
      </svg>
    `;
  },

  // 19. Handcrafted 3D Glass Story / Lightning Icon
  getGlassLightning(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <polygon points="13,2 3,14 12,14 11,22 21,10 12,10" fill="url(#glass-gold-grad)" stroke="#ffffff" stroke-width="1" style="filter: drop-shadow(0 0 6px #ffb703);"/>
      </svg>
    `;
  },

  // 20. Handcrafted 3D Glass Save Download Tray Icon
  getGlassDownload(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M21 15V19C21 20.1 20.1 21 19 21H5C3.9 21 3 20.1 3 19V15" stroke="url(#glass-cyan-blue)" stroke-width="2" stroke-linecap="round"/>
        <path d="M12 3V14M12 14L8 10M12 14L16 10" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  },

  // 21. Handcrafted 3D Glass Rocket Publish Icon
  getGlassRocket(size = 22) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none">
        <path d="M4.5 16.5C3 18 3 21 3 21C3 21 6 21 7.5 19.5L12 15L9 12L4.5 16.5Z" fill="url(#glass-fire-grad)"/>
        <path d="M12 15L19 8C20.5 6.5 21 3 21 3C21 3 17.5 3.5 16 5L9 12L12 15Z" fill="url(#glass-cyan-blue)" stroke="#ffffff" stroke-width="1"/>
        <circle cx="15.5" cy="8.5" r="1.5" fill="#ffffff"/>
      </svg>
    `;
  }
};

window.GlassAssets = GlassAssets;
