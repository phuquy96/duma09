/**
 * iOS 26 Glass Direct Messaging Engine (TikTok Vision 26 Chat)
 * Ultra-dark Frosted Glass Bubbles, Custom 3D Glass Emojis, Avatars & @usernames
 */

class GlassChatEngine {
  constructor() {
    this.conversations = [
      {
        id: 1,
        name: 'Elysia Vũ ✦',
        username: 'elysia.2026',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        online: true,
        lastActive: 'Đang hoạt động',
        messages: [
          {
            id: 1,
            sender: 'them',
            text: 'Chào bạn! Cảm ơn bạn đã xem và thả tim video Neo Tokyo của mình nha ✨ Bạn có thích hiệu ứng kính iOS 26 không?',
            time: '21:42',
            reactions: ['heart']
          },
          {
            id: 2,
            sender: 'me',
            text: 'Giao diện kính đục mờ đẹp dã man luôn Elysia ơi! Nhìn mấy cái emoji 3D tự thiết kế đỉnh thật sự 🔥💎',
            time: '21:44',
            reactions: ['fire']
          },
          {
            id: 3,
            sender: 'them',
            type: 'voice',
            duration: '0:14',
            waveform: [40, 70, 90, 60, 80, 100, 75, 45, 85, 95, 60, 30, 70, 50],
            time: '21:45',
            reactions: []
          },
          {
            id: 4,
            sender: 'them',
            text: 'Mình vừa gửi cho bạn bản demo âm thanh Spatial Audio mới nhất trong tin nhắn thoại đấy, bạn nghe thử đi!',
            time: '21:45',
            reactions: ['star']
          }
        ]
      },
      {
        id: 2,
        name: 'Vinh Xô Spatial',
        username: 'tech_future.vn',
        avatar: 'assets/tiktok_video_spatial_gadget_1790520651574.jpg',
        online: true,
        lastActive: 'Hoạt động 5 phút trước',
        messages: [
          {
            id: 1,
            sender: 'them',
            text: 'Chiếc iPhone 26 Pro Holographic kính trong suốt này dùng sướng cực kỳ bạn ạ! Màn hình không còn viền đen luôn.',
            time: '20:15',
            reactions: ['thumbsup']
          }
        ]
      },
      {
        id: 3,
        name: 'Mai Dancer',
        username: 'mai_dancer26',
        avatar: 'assets/tiktok_avatar_creator_lisa_1790520668800.jpg',
        online: false,
        lastActive: 'Hoạt động 1 giờ trước',
        messages: [
          {
            id: 1,
            sender: 'them',
            text: 'Hôm nào làm video duet điệu nhảy Cyberpunk chung nha bạn ơi 💃⚡',
            time: '18:30',
            reactions: ['heart']
          }
        ]
      }
    ];

    this.activeConvId = 1;
    this.init();
  }

  init() {
    this.renderConversationsList();
    this.setupEventListeners();
  }

  getActiveConversation() {
    return this.conversations.find(c => c.id === this.activeConvId) || this.conversations[0];
  }

  renderConversationsList() {
    const container = document.getElementById('chatConversationsList');
    if (!container) return;

    container.innerHTML = this.conversations.map(c => {
      const lastMsg = c.messages[c.messages.length - 1];
      const previewText = lastMsg.type === 'voice' ? '🎙️ Tin nhắn thoại (0:14)' : lastMsg.text;
      return `
        <div class="chat-conv-item ${c.id === this.activeConvId ? 'active' : ''}" data-conv-id="${c.id}">
          <div class="conv-avatar-box">
            <img class="conv-avatar" src="${c.avatar}" alt="${c.name}">
            ${c.online ? '<div class="online-glass-badge"></div>' : ''}
          </div>
          <div class="conv-info-box">
            <div class="conv-title-row">
              <span class="conv-name">${c.name}</span>
              <span class="conv-time">${lastMsg.time}</span>
            </div>
            <div class="conv-username">@${c.username}</div>
            <div class="conv-preview-text">${previewText}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  openChat(convId) {
    this.activeConvId = convId;
    this.renderChatWindow();
    const chatModal = document.getElementById('directChatModal');
    if (chatModal) {
      chatModal.classList.add('open');
      if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
    }
  }

  closeChat() {
    const chatModal = document.getElementById('directChatModal');
    if (chatModal) {
      chatModal.classList.remove('open');
      if (window.tikTokApp) window.tikTokApp.playGlassSound('click');
    }
  }

  renderChatWindow() {
    const conv = this.getActiveConversation();
    if (!conv) return;

    // Update Header
    const headerAvatar = document.getElementById('chatHeaderAvatar');
    const headerName = document.getElementById('chatHeaderName');
    const headerUsername = document.getElementById('chatHeaderUsername');
    const headerStatus = document.getElementById('chatHeaderStatus');

    if (headerAvatar) headerAvatar.src = conv.avatar;
    if (headerName) headerName.textContent = conv.name;
    if (headerUsername) headerUsername.textContent = `@${conv.username}`;
    if (headerStatus) headerStatus.textContent = conv.lastActive;

    // Render Messages Stream
    const stream = document.getElementById('chatMessagesStream');
    if (!stream) return;

    stream.innerHTML = `
      <div class="chat-date-pill">Hôm nay · iOS 26 End-to-End Encrypted</div>
      ${conv.messages.map(msg => this.renderMessageBubble(msg, conv)).join('')}
    `;

    // Scroll to bottom smoothly
    stream.scrollTop = stream.scrollHeight;
  }

  renderMessageBubble(msg, conv) {
    const isMe = msg.sender === 'me';
    let bubbleContent = '';

    if (msg.type === 'voice') {
      bubbleContent = `
        <div class="voice-msg-player">
          <button class="voice-play-btn" onclick="window.glassChat.playVoiceSnippet(this)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#ffffff"><polygon points="6,4 20,12 6,20"/></svg>
          </button>
          <div class="voice-bars">
            ${msg.waveform.map(h => `<span style="height: ${h * 0.24}px"></span>`).join('')}
          </div>
          <span class="voice-duration">${msg.duration}</span>
        </div>
      `;
    } else if (msg.type === 'image') {
      bubbleContent = `
        <div class="chat-img-bubble">
          <img src="${msg.imgUrl}" alt="attached image">
        </div>
      `;
    } else {
      bubbleContent = `<div class="msg-text">${msg.text}</div>`;
    }

    // Handcrafted Glass Emoji Reactions
    const reactionsHtml = msg.reactions && msg.reactions.length > 0 ? `
      <div class="msg-reactions-tray">
        ${msg.reactions.map(r => this.getReactionSvg(r)).join('')}
      </div>
    ` : '';

    return `
      <div class="chat-message-row ${isMe ? 'msg-sent' : 'msg-received'}">
        ${!isMe ? `<img class="msg-sender-avatar" src="${conv.avatar}" alt="${conv.username}">` : ''}
        <div class="msg-bubble-wrapper">
          <div class="glass-message-bubble ${isMe ? 'bubble-me' : 'bubble-them'}" data-msg-id="${msg.id}">
            ${bubbleContent}
            <div class="msg-meta-row">
              <span class="msg-timestamp">${msg.time}</span>
              ${isMe ? '<span class="msg-read-status">✓✓</span>' : ''}
            </div>
            ${reactionsHtml}
          </div>
        </div>
      </div>
    `;
  }

  getReactionSvg(type) {
    switch(type) {
      case 'heart': return GlassAssets.getGlassHeart(true, 18);
      case 'fire': return GlassAssets.getGlassFlame(18);
      case 'laugh': return GlassAssets.getGlassLaughTears(18);
      case 'star': return GlassAssets.getGlassStarStruck(18);
      case 'mindblown': return GlassAssets.getGlassMindBlown(18);
      default: return GlassAssets.getGlassThumbsUp(18);
    }
  }

  playVoiceSnippet(btn) {
    if (window.tikTokApp) {
      window.tikTokApp.playGlassSound('heart');
    }
    btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="#ffffff"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>`;
    setTimeout(() => {
      btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="#ffffff"><polygon points="6,4 20,12 6,20"/></svg>`;
    }, 2500);
  }

  sendMessage(text, type = 'text', extra = {}) {
    if (!text && type === 'text') return;
    const conv = this.getActiveConversation();
    if (!conv) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const newMsg = {
      id: Date.now(),
      sender: 'me',
      type: type,
      text: text,
      time: timeStr,
      reactions: ['heart'],
      ...extra
    };

    conv.messages.push(newMsg);
    this.renderChatWindow();
    this.renderConversationsList();

    if (window.tikTokApp) window.tikTokApp.playGlassSound('heart');

    // Simulate smart AI/creator reply after 1.8 seconds with Dynamic Island alert
    this.simulateIncomingReply(conv);
  }

  simulateIncomingReply(conv) {
    const typingIndicator = document.getElementById('chatTypingIndicator');
    if (typingIndicator) typingIndicator.style.display = 'flex';

    setTimeout(() => {
      if (typingIndicator) typingIndicator.style.display = 'none';

      const replies = [
        'Ý tưởng của bạn hay quá! Mình sẽ áp dụng hiệu ứng kính iOS 26 này vào video kế tiếp nha ✨',
        'Cảm ơn bạn nhiều nhé! Chúc bạn lướt TikTok Vision 26 thật chill 💎🎵',
        'Haha chuẩn luôn bạn ơi! Nhìn mấy bong bóng kính mờ này mượt mà xuất sắc luôn á 👏🔥'
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      conv.messages.push({
        id: Date.now(),
        sender: 'them',
        type: 'text',
        text: randomReply,
        time: timeStr,
        reactions: ['fire']
      });

      this.renderChatWindow();
      this.renderConversationsList();

      if (window.tikTokApp) {
        window.tikTokApp.playGlassSound('glass');
      }

      // Notify in Dynamic Island
      this.showDynamicIslandNotification(`@${conv.username}: ${randomReply}`);
    }, 2000);
  }

  showDynamicIslandNotification(text) {
    const island = document.getElementById('dynamicIsland');
    const label = document.getElementById('islandLabel');
    if (!island || !label) return;

    island.classList.add('expanded');
    label.innerHTML = `💬 <strong>${text.substring(0, 32)}...</strong>`;
    setTimeout(() => {
      island.classList.remove('expanded');
      if (window.tikTokApp) window.tikTokApp.updateDynamicIslandForCurrentVideo();
    }, 4500);
  }

  setupEventListeners() {
    const convList = document.getElementById('chatConversationsList');
    if (convList) {
      convList.addEventListener('click', (e) => {
        const item = e.target.closest('.chat-conv-item');
        if (!item) return;
        const convId = parseInt(item.dataset.convId);
        this.openChat(convId);
      });
    }

    const closeBtn = document.getElementById('closeDirectChatBtn');
    if (closeBtn) closeBtn.addEventListener('click', () => this.closeChat());

    const sendBtn = document.getElementById('chatSendBtn');
    const input = document.getElementById('chatMsgInput');

    const handleSend = () => {
      const val = input.value.trim();
      if (!val) return;
      this.sendMessage(val);
      input.value = '';
    };

    if (sendBtn) sendBtn.addEventListener('click', handleSend);
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleSend();
      });
    }

    // Quick glass emoji reaction buttons in chat input
    const emojiTrayBtn = document.getElementById('chatEmojiTrayBtn');
    const emojiTray = document.getElementById('chatEmojiTray');
    if (emojiTrayBtn && emojiTray) {
      emojiTray.innerHTML = `
        <div class="tray-emoji" data-e="❤️">${GlassAssets.getGlassHeart(true, 24)}</div>
        <div class="tray-emoji" data-e="🔥">${GlassAssets.getGlassFlame(24)}</div>
        <div class="tray-emoji" data-e="😂">${GlassAssets.getGlassLaughTears(24)}</div>
        <div class="tray-emoji" data-e="🤩">${GlassAssets.getGlassStarStruck(24)}</div>
        <div class="tray-emoji" data-e="🤯">${GlassAssets.getGlassMindBlown(24)}</div>
        <div class="tray-emoji" data-e="👍">${GlassAssets.getGlassThumbsUp(24)}</div>
      `;

      emojiTrayBtn.addEventListener('click', () => {
        emojiTray.classList.toggle('open');
        if (window.tikTokApp) window.tikTokApp.playGlassSound('glass');
      });

      emojiTray.addEventListener('click', (e) => {
        const item = e.target.closest('.tray-emoji');
        if (!item) return;
        input.value += ' ' + item.dataset.e;
        input.focus();
        emojiTray.classList.remove('open');
      });
    }

    // Media attachment simulation
    const attachBtn = document.getElementById('chatAttachBtn');
    const fileInput = document.getElementById('chatFileInput');
    if (attachBtn && fileInput) {
      attachBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            this.sendMessage('Ảnh đính kèm', 'image', { imgUrl: event.target.result });
          };
          reader.readAsDataURL(file);
        }
      });
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.glassChat = new GlassChatEngine();
});
